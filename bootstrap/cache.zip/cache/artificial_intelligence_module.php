<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ArtificialIntelligence\\Providers\\ArtificialIntelligenceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ArtificialIntelligence\\Providers\\ArtificialIntelligenceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);